# Hazratgunj Restaurant & Banquet Hall

Yeh GitHub Pages ke liye static website package hai. `index.html` ko seedha
publish kiya ja sakta hai; Bun, Node.js, ya build command ki zaroorat nahi hai.

## GitHub Pages par live karein

1. ZIP download karke extract karein.
2. Extract ki hui files ko GitHub repository ke **root** mein upload karein.
   Dhyan rahe `index.html` repository ke root mein ho, kisi nested folder ke
   andar nahi.
3. Repository mein **Settings → Pages** kholen.
4. **Build and deployment** ke neeche **Deploy from a branch** chunein.
5. Apni branch (aam taur par `main`) aur folder `/(root)` select karke **Save**
   karein.
6. GitHub Pages ka URL isi Pages screen par dikhne ke baad website kholen.

Selected branch/root par agle commits bhi site ko update karenge.

## Live karne se pehle jaanch

- Menu mein kai items, descriptions, tasveerein aur prices sample hain.
- Restaurant ka phone/WhatsApp, address, opening hours aur pricing ko confirm
  karein.
- Illustrative food aur banquet photos ko asli restaurant photos se badlein.
- Privacy, terms aur refund/order policy ka apna approved text jodein.
- Sirf approved guest reviews aur confirmed event/banquet claims publish karein.

## Zaroori technical baatein

- Site static hai; koi database, online payment, order-processing backend,
  persistent CMS ya analytics integration shamil nahi hai. Calls aur enquiries
  phone/WhatsApp ke zariye jaati hain.
- Owner Content Studio ke edits page mein tab tak rehte hain; **Export settings**
  se JSON download karke backup rakhein. Yeh GitHub par khud se publish ya
  permanent save nahi hote. Site content badalne ke baad updated `index.html`
  repository mein commit karein.
- Photos Unsplash, fonts Google Fonts, aur map Google Maps se load hote hain.
  Inhein dekhne ke liye visitor ko internet connection chahiye.
